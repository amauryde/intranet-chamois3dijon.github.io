<?php
//ESPACE DISQUE / NB USERS / DB CONFIG
define("limite_espace_disque", "10737418240");
define("limite_nb_users", "10000");
define("db_host", "");
define("db_name", "");
define("db_login", "");
define("db_password", '');
